# Member 4 - LLM & AI Response Generation (SERC)

    pip install -r requirements.txt
    python -m unittest tests.test_member4      # 14 offline tests, no API key
    python demo.py                              # offline end-to-end demo with a fake LLM
    USE_REAL=gpt4o OPENAI_API_KEY=... python demo.py
    python -m serc_llm.compare_models --alerts data/alerts.jsonl --refs data/ground_truth.jsonl --models gpt4o pixtral --out results/

| Task (from your role sheet)          | File                          |
|--------------------------------------|-------------------------------|
| Alert summarization / extraction     | serc_llm/alert_extractor.py   |
| Prompt templates                     | serc_llm/prompts.py           |
| Combine alert + retrieved context    | serc_llm/prompt_builder.py    |
| Connect LLM                          | serc_llm/llm_client.py        |
| Investigation / mitigation guidance  | serc_llm/response_generator.py|
| Follow-up question handling          | serc_llm/conversation.py      |
| Compare model responses              | serc_llm/metrics.py, compare_models.py |
| Contract with Member 3 (retrieval)   | serc_llm/retriever_iface.py   |

Integration with Member 3: implement `Retriever.retrieve(alert, query=None) -> RetrievedContext`
(chunks with .text, .source in {general,nist,mitre}, .score = Qdrant cosine, .metadata['technique_id'] for MITRE).
Then `SERCResponder(make_client("gpt4o"), YourRetriever())`.

Before real use: confirm model ids in config.py are available to your account; calibrate
RetrievalPolicy.min_score on real queries; hosted OpenAI/Mistral APIs ignore top_k (only self-hosted vLLM honours it).
