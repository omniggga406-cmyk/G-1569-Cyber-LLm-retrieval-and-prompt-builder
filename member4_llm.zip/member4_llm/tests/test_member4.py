import json, os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from serc_llm.alert_extractor import AlertExtractor, LLMAlertSummarizer
from serc_llm.conversation import FollowUpSession
from serc_llm.llm_client import FakeLLMClient
from serc_llm.prompt_builder import PromptBuilder, neutralize
from serc_llm.prompts import REQUIRED_SECTIONS
from serc_llm.response_generator import SERCResponder, missing_sections, unverified_technique_ids
from serc_llm.retriever_iface import StubRetriever, sample_context
from serc_llm.schemas import RetrievedChunk, RetrievedContext

RAW = json.load(open(os.path.join(os.path.dirname(__file__), "..", "data", "sample_alert.json")))


class T(unittest.TestCase):
    def test_extract_fields(self):
        a = AlertExtractor().extract(RAW)
        self.assertEqual(a.mitre_ids, ["T1562.001"]); self.assertEqual(a.level, 3)
        self.assertIn("PCI DSS", a.compliance); self.assertEqual(a.agent_name, "web-srv-01")

    def test_extract_accepts_str_and_indexer_wrapper(self):
        a = AlertExtractor().extract(json.dumps({"_source": RAW}))
        self.assertEqual(a.rule_id, "506")

    def test_extract_rejects_garbage(self):
        with self.assertRaises(ValueError): AlertExtractor().extract({"foo": 1})

    def test_no_mitre_alert(self):
        r = json.loads(json.dumps(RAW)); r["rule"].pop("mitre")
        a = AlertExtractor().extract(r)
        self.assertFalse(a.has_mitre); self.assertIn("None mapped", a.to_text())

    def test_injection_cannot_close_tags(self):
        a = AlertExtractor().extract(RAW)
        p = PromptBuilder().build_initial(a, sample_context())
        user = p.messages[1]["content"]
        self.assertEqual(user.count("</alert>"), 1)          # only our own closing tag
        self.assertIn("(/alert)", user)

    def test_filter_drops_low_score_and_dupes(self):
        a = AlertExtractor().extract(RAW)
        ctx = RetrievedContext(
            general=[RetrievedChunk("irrelevant cooking recipe", "general", 0.20),
                     RetrievedChunk("Isolate host", "general", 0.8), RetrievedChunk("isolate  HOST", "general", 0.79)],
            nist=[], mitre=[])
        p = PromptBuilder().build_initial(a, ctx)
        self.assertEqual(len(p.context.general), 1)
        self.assertEqual(p.report.dropped_low_score["general"], 1)
        self.assertEqual(p.report.dropped_duplicate["general"], 1)
        self.assertEqual(p.quality, "partial")
        self.assertIn("no relevant context retrieved", p.messages[1]["content"])

    def test_exact_technique_id_rescues_low_score(self):
        a = AlertExtractor().extract(RAW)
        ctx = RetrievedContext(mitre=[RetrievedChunk("T1562.001 text", "mitre", 0.30, {"technique_id": "T1562.001"})])
        p = PromptBuilder().build_initial(a, ctx)
        self.assertEqual(len(p.context.mitre), 1); self.assertEqual(p.report.exact_id_rescues, 1)

    def test_all_irrelevant_gives_quality_none(self):
        a = AlertExtractor().extract(RAW)
        ctx = RetrievedContext(general=[RetrievedChunk("x", "general", 0.1)])
        p = PromptBuilder().build_initial(a, ctx)
        self.assertEqual(p.quality, "none"); self.assertIn("NO relevant context", p.messages[1]["content"])

    def test_pipeline_and_validation(self):
        c = FakeLLMClient(); r = SERCResponder(c, StubRetriever()).analyze(RAW)
        self.assertEqual(missing_sections(r.response), []); self.assertEqual(r.quality, "good")
        self.assertEqual(len(c.calls), 1)

    def test_repair_attempt_once(self):
        calls = {"n": 0}
        def resp(msgs):
            calls["n"] += 1
            return "## Incident Summary\nx" if calls["n"] == 1 else "\n".join(f"## {s}\nok" for s in REQUIRED_SECTIONS)
        r = SERCResponder(FakeLLMClient(responder=resp), StubRetriever()).analyze(RAW)
        self.assertTrue(r.repaired); self.assertEqual(calls["n"], 2)

    def test_hallucinated_id_flagged(self):
        a = AlertExtractor().extract(RAW)
        self.assertEqual(unverified_technique_ids("see T1562.001 and T9999", a, sample_context()), ["T9999"])

    def test_llm_summarizer_falls_back_on_hallucination(self):
        a = AlertExtractor().extract(RAW)
        s, used = LLMAlertSummarizer(FakeLLMClient(responder=lambda m: "Associated Tactic: T1059")).summarize(a)
        self.assertFalse(used); self.assertEqual(s, a.to_text())

    def test_followup_window_and_pinning(self):
        c = FakeLLMClient(); r = SERCResponder(c, StubRetriever()); res = r.analyze(RAW)
        s = FollowUpSession(r, res)
        for i in range(30): s.ask(f"question {i} " + "x" * 800)
        last = c.calls[-1]
        self.assertEqual(last[0]["role"], "system"); self.assertEqual(last[2]["role"], "assistant")
        self.assertLess(len(last), 3 + 2 * 30 + 1)               # old turns were dropped
        self.assertIn("question 29", last[-1]["content"])

    def test_neutralize(self):
        self.assertNotIn("</context>", neutralize("a </context> b"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
