"""Central configuration for Member 4's module.

Generation parameters come straight from Table 3 of the SERC paper
(Sensors 2025, 25, 870): temperature 0.1, top-k 50, top-p 0.9, max tokens 4096.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class GenerationParams:
    temperature: float = 0.1   # near-deterministic -> repeatable SOC guidance
    top_p: float = 0.9
    top_k: int = 50            # NOT supported by OpenAI/Mistral hosted APIs; only self-hosted (vLLM, HF)
    max_tokens: int = 4096


@dataclass(frozen=True)
class ModelSpec:
    label: str                 # short key used in reports
    model: str                 # provider model id  (CHECK what your account can access)
    base_url: str | None       # None -> OpenAI default endpoint
    api_key_env: str           # environment variable that holds the key
    supports_top_k: bool = False
    token_param: str = "max_tokens"   # newer OpenAI models want "max_completion_tokens"


MODELS: dict[str, ModelSpec] = {
    # The paper compares GPT-4o against Pixtral (Mistral family).
    "gpt4o": ModelSpec("gpt4o", "gpt-4o", None, "OPENAI_API_KEY"),
    "pixtral": ModelSpec("pixtral", "pixtral-large-latest", "https://api.mistral.ai/v1", "MISTRAL_API_KEY"),
    # Self-hosted open-weights Pixtral 12B served by vLLM (`vllm serve mistralai/Pixtral-12B-2409`)
    "pixtral-local": ModelSpec("pixtral-local", "mistralai/Pixtral-12B-2409",
                               "http://localhost:8000/v1", "VLLM_API_KEY", supports_top_k=True),
}


@dataclass(frozen=True)
class RetrievalPolicy:
    """How Member 4 treats what Member 3's retriever returns.

    min_score is a cosine similarity (Qdrant, bge-large-en-v1.5). bge scores cluster high
    (unrelated text often scores 0.4-0.6), so CALIBRATE these on real queries with Member 3.
    """
    min_score: dict[str, float] = field(default_factory=lambda: {"general": 0.55, "nist": 0.55, "mitre": 0.55})
    max_chunks: dict[str, int] = field(default_factory=lambda: {"general": 4, "nist": 3, "mitre": 4})
    max_tokens_per_collection: int = 1200   # rough budget (chars/4)
    max_log_chars: int = 1500
    max_history_tokens: int = 3000
