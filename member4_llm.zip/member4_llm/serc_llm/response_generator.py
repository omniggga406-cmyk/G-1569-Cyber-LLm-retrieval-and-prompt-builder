"""Responsibilities 5 & 1 glue: generate investigation / mitigation guidance.

Pipeline:  raw Wazuh JSON -> extract -> retrieve (Member 3) -> filter+build prompt -> LLM -> validate -> result
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .alert_extractor import AlertExtractor, LLMAlertSummarizer
from .config import GenerationParams, RetrievalPolicy
from .llm_client import LLMClient, LLMResult
from .prompt_builder import BuiltPrompt, PromptBuilder
from .prompts import REPAIR_PROMPT, REQUIRED_SECTIONS
from .retriever_iface import Retriever
from .schemas import ExtractedAlert, RetrievedContext

_TID = re.compile(r"\bT\d{4}(?:\.\d{3})?\b")


def missing_sections(text: str) -> list[str]:
    heads = {re.sub(r"\s+", " ", h).strip().lower() for h in re.findall(r"^#{1,3}\s*(.+?)\s*$", text, re.M)}
    return [s for s in REQUIRED_SECTIONS if s.lower() not in heads]


def unverified_technique_ids(text: str, alert: ExtractedAlert, ctx: RetrievedContext) -> list[str]:
    """Technique IDs the answer cites that are in neither the alert nor the retrieved MITRE context."""
    allowed = set(alert.mitre_ids) | set(_TID.findall(" ".join(c.text for c in ctx.mitre)))
    allowed |= {a.split(".")[0] for a in allowed}
    return sorted(set(_TID.findall(text)) - allowed)


@dataclass
class AnalysisResult:
    alert: ExtractedAlert
    alert_text: str
    llm_extraction_used: bool
    prompt: BuiltPrompt
    response: str
    llm: LLMResult
    warnings: list[str] = field(default_factory=list)
    repaired: bool = False

    @property
    def quality(self) -> str:
        return self.prompt.quality


class SERCResponder:
    def __init__(self, client: LLMClient, retriever: Retriever,
                 params: GenerationParams | None = None, policy: RetrievalPolicy | None = None,
                 summarizer_client: LLMClient | None = None):
        self.client, self.retriever = client, retriever
        self.params = params or GenerationParams()
        self.policy = policy or RetrievalPolicy()
        self.extractor = AlertExtractor(self.policy.max_log_chars)
        self.builder = PromptBuilder(self.policy)
        # Optional: use an LLM for Table-4 extraction (paper does this with Pixtral-Large)
        self.summarizer = LLMAlertSummarizer(summarizer_client, self.params) if summarizer_client else None

    def analyze(self, raw_alert: dict | str, ctx: RetrievedContext | None = None) -> AnalysisResult:
        """`ctx` lets the comparison script feed identical context to every model (fair test)."""
        alert = self.extractor.extract(raw_alert)
        alert_text, used_llm = (self.summarizer.summarize(alert) if self.summarizer else (alert.to_text(), False))
        if ctx is None:
            ctx = self.retriever.retrieve(alert)
        built = self.builder.build_initial(alert, ctx, alert_text)
        res = self.client.generate(built.messages, self.params)
        text, warnings, repaired = res.text, [], False

        gaps = missing_sections(text)
        if gaps:                                         # one repair attempt, never a loop
            msgs = built.messages + [{"role": "assistant", "content": text},
                                     {"role": "user", "content": REPAIR_PROMPT.format(missing=", ".join(gaps))}]
            res2 = self.client.generate(msgs, self.params)
            if not missing_sections(res2.text):
                text, res, repaired = res2.text, res2, True
            else:
                warnings.append(f"missing sections after repair: {', '.join(missing_sections(res2.text))}")
        if res.finish_reason == "length":
            warnings.append("response truncated by max_tokens")
        bad = unverified_technique_ids(text, alert, built.context)
        if bad:
            warnings.append(f"technique IDs not found in alert or retrieved context: {', '.join(bad)}")
        if built.quality != "good":
            warnings.append(f"context quality = {built.quality}")
        return AnalysisResult(alert, alert_text, used_llm, built, text, res, warnings, repaired)
