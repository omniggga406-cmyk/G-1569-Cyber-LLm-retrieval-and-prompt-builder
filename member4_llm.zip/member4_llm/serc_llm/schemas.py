"""Plain data containers shared by every module."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Wazuh rule levels run 0-15. These bands are a design choice (documented in README);
# the paper's own example labels level 3 as "Medium", so state your convention in the report.
SEVERITY_BANDS = [(0, 3, "Low"), (4, 7, "Medium"), (8, 11, "High"), (12, 15, "Critical")]


def severity_label(level: int | None) -> str:
    if level is None:
        return "Unknown"
    for lo, hi, name in SEVERITY_BANDS:
        if lo <= level <= hi:
            return name
    return "Unknown"


@dataclass
class ExtractedAlert:
    description: str
    level: int | None
    rule_id: str | None
    timestamp: str | None
    agent_name: str | None
    agent_ip: str | None
    mitre_ids: list[str]
    tactics: list[str]
    techniques: list[str]
    compliance: dict[str, list[str]]
    log_detail: str
    event_data: dict[str, Any]
    raw: dict = field(default_factory=dict, repr=False)

    @property
    def severity(self) -> str:
        return severity_label(self.level)

    @property
    def has_mitre(self) -> bool:
        return bool(self.mitre_ids)

    def to_text(self) -> str:
        """Paper-style 'Extracted Problem' text (Table 4 output format), built deterministically."""
        if self.has_mitre:
            tech = "; ".join(self.techniques) or "n/a"
            tactic = (f"{', '.join(self.tactics) or 'n/a'} "
                      f"(MITRE ID: {', '.join(self.mitre_ids)} - {tech})")
        else:
            tactic = "None mapped by the Wazuh rule"
        comp = "; ".join(f"{k} ({', '.join(v)})" for k, v in self.compliance.items()) or "None listed"
        lines = [
            f"Description: {self.description}",
            f"Alert Level: {self.level if self.level is not None else 'n/a'} ({self.severity} severity)",
            f"Rule ID: {self.rule_id or 'n/a'}",
            f"Associated Tactic: {tactic}",
            f"Compliance Concerns: {comp}",
        ]
        if self.agent_name:
            lines.append(f"Agent: {self.agent_name}" + (f" ({self.agent_ip})" if self.agent_ip else ""))
        if self.timestamp:
            lines.append(f"Timestamp: {self.timestamp}")
        if self.event_data:
            lines.append("Event Data: " + "; ".join(f"{k}={v}" for k, v in self.event_data.items()))
        lines.append(f"Log Details: {self.log_detail or 'n/a'}")
        return "\n".join(lines)

    def retrieval_queries(self) -> dict[str, str]:
        """Suggested per-collection queries for Member 3's retriever."""
        base = self.description
        tac = ", ".join(self.tactics)
        tech = ", ".join(self.techniques)
        ids = ", ".join(self.mitre_ids)
        return {
            "general": f"incident response procedure: {base} {tac}".strip(),
            "nist": f"NIST CSF 2.0 detect respond recover guidance for: {base} {tac}".strip(),
            "mitre": f"{ids} {tech} {tac} mitigation detection".strip() if self.has_mitre
            else f"{base} adversary technique mitigation",
        }

    def prompt_view(self) -> dict[str, Any]:
        """Compact, bounded dict that is safe to put inside a prompt."""
        return {
            "description": self.description, "level": self.level, "severity": self.severity,
            "rule_id": self.rule_id, "timestamp": self.timestamp,
            "agent": self.agent_name, "agent_ip": self.agent_ip,
            "mitre_ids": self.mitre_ids, "tactics": self.tactics, "techniques": self.techniques,
            "compliance": self.compliance, "event_data": self.event_data, "log_detail": self.log_detail,
        }


@dataclass
class RetrievedChunk:
    text: str
    source: str                      # "general" | "nist" | "mitre"
    score: float | None = None       # cosine similarity from Qdrant
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RetrievedContext:
    general: list[RetrievedChunk] = field(default_factory=list)
    nist: list[RetrievedChunk] = field(default_factory=list)
    mitre: list[RetrievedChunk] = field(default_factory=list)

    def by_name(self) -> dict[str, list[RetrievedChunk]]:
        return {"general": self.general, "nist": self.nist, "mitre": self.mitre}

    def total(self) -> int:
        return len(self.general) + len(self.nist) + len(self.mitre)


QUALITY_GOOD, QUALITY_PARTIAL, QUALITY_NONE = "good", "partial", "none"
