"""Responsibility 6: follow-up question handling."""
from __future__ import annotations

from .llm_client import LLMResult
from .prompt_builder import est_tokens
from .response_generator import AnalysisResult, SERCResponder


class FollowUpSession:
    """Stateful chat attached to one analysed alert.

    - Pinned head   : system prompt + alert + the guide already given (never trimmed)
    - Rolling window: previous Q/A pairs, oldest dropped first when over the token budget
    - Fresh retrieval per question, so 'how do I check for persistence?' pulls persistence material
    """

    def __init__(self, responder: SERCResponder, analysis: AnalysisResult, use_retrieval: bool = True):
        self.r, self.a, self.use_retrieval = responder, analysis, use_retrieval
        self.pinned = responder.builder.pinned_messages(analysis.alert, analysis.response, analysis.alert_text)
        self.history: list[dict[str, str]] = []

    def _trim(self) -> list[dict[str, str]]:
        budget = self.r.policy.max_history_tokens
        h = list(self.history)
        while h and sum(est_tokens(m["content"]) for m in h) > budget:
            h = h[2:]                         # drop the oldest user+assistant pair
        return h

    def ask(self, question: str) -> tuple[str, LLMResult, str]:
        question = question.strip()
        if not question:
            raise ValueError("Empty question")
        ctx = self.r.retriever.retrieve(self.a.alert, query=question) if self.use_retrieval else None
        built = self.r.builder.build_followup(self.a.alert, self.pinned, self._trim(), question, ctx)
        res = self.r.client.generate(built.messages, self.r.params)
        self.history += [{"role": "user", "content": question}, {"role": "assistant", "content": res.text}]
        return res.text, res, built.quality
