"""Run the same alerts + identical retrieved context through several LLMs and score them.

Usage:
  python -m serc_llm.compare_models --alerts data/alerts.jsonl --refs data/ground_truth.jsonl \
        --models gpt4o pixtral --out results/

alerts.jsonl       : one Wazuh alert JSON per line
ground_truth.jsonl : one {"scenario": "...", "reference": "..."} per line, same order
"""
from __future__ import annotations

import argparse
import csv
import json
import os

from .config import GenerationParams
from .llm_client import LLMClient, make_client
from .metrics import bertscore, cosine_scores, structural, summarize, wilcoxon
from .response_generator import SERCResponder
from .retriever_iface import Retriever, StubRetriever


def run_comparison(alerts: list[dict], refs: list[str], clients: dict[str, LLMClient], retriever: Retriever,
                   out_dir: str, with_semantic_metrics: bool = True, params: GenerationParams | None = None) -> list[dict]:
    os.makedirs(out_dir, exist_ok=True)
    rows: list[dict] = []
    probe = SERCResponder(next(iter(clients.values())), retriever, params)
    for i, raw in enumerate(alerts, 1):
        alert = probe.extractor.extract(raw)
        ctx = retriever.retrieve(alert)                    # retrieve ONCE -> identical context for every model
        for label, client in clients.items():
            res = SERCResponder(client, retriever, params).analyze(raw, ctx=ctx)
            rows.append({"scenario": i, "model": label, "response": res.response,
                         "latency_s": round(res.llm.latency_s, 2),
                         "prompt_tokens": res.llm.prompt_tokens, "completion_tokens": res.llm.completion_tokens,
                         "context_quality": res.quality, "warnings": "; ".join(res.warnings),
                         **structural(res.response, res.alert, res.prompt.context)})
    if with_semantic_metrics:
        cands = [r["response"] for r in rows]
        gts = [refs[r["scenario"] - 1] for r in rows]
        for r, c in zip(rows, cosine_scores(cands, gts)):
            r["cosine"] = c
        bs = bertscore(cands, gts)
        for k in ("precision", "recall", "f1"):
            for r, v in zip(rows, bs[k]):
                r[f"bert_{k}"] = v
    with open(os.path.join(out_dir, "responses.jsonl"), "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    cols = [c for c in rows[0] if c != "response"]
    with open(os.path.join(out_dir, "metrics.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows({c: r.get(c) for c in cols} for r in rows)
    return rows


def print_summary(rows: list[dict]) -> None:
    models = sorted({r["model"] for r in rows})
    for key in ("cosine", "bert_precision", "bert_recall", "bert_f1", "latency_s", "completion_tokens",
                "missing_sections", "unverified_ids"):
        s = summarize(rows, key)
        if s:
            print(f"{key:18s}", "  ".join(f"{m}: {mu:.4f}+-{sd:.4f}" for m, (mu, sd) in s.items()))
    if len(models) == 2:
        for key in ("cosine", "bert_f1"):
            p = wilcoxon(rows, key, *models)
            if p is not None:
                print(f"Wilcoxon {key} {models[0]} vs {models[1]}: p={p:.4f}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--alerts", required=True)
    ap.add_argument("--refs", required=True)
    ap.add_argument("--models", nargs="+", default=["gpt4o", "pixtral"])
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    alerts = [json.loads(l) for l in open(a.alerts, encoding="utf-8") if l.strip()]
    refs = [json.loads(l)["reference"] for l in open(a.refs, encoding="utf-8") if l.strip()]
    # TODO(Member 3 integration): replace StubRetriever with the Qdrant retriever
    rows = run_comparison(alerts, refs, {m: make_client(m) for m in a.models}, StubRetriever(), a.out)
    print_summary(rows)


if __name__ == "__main__":
    main()
