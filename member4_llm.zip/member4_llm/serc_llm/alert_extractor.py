"""Responsibility 1: alert summarization / extraction.

Two layers (this is a deliberate design point for the viva):
  1. AlertExtractor      - deterministic parsing of the Wazuh JSON. Free, instant, cannot hallucinate.
  2. LLMAlertSummarizer  - the paper's Table-4 one-shot LLM extraction, validated against layer 1.
"""
from __future__ import annotations

import json
import re
from typing import Any

from .config import GenerationParams
from .llm_client import LLMClient
from .prompts import EXTRACTION_PROMPT
from .schemas import ExtractedAlert

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

COMPLIANCE_KEYS = {
    "pci_dss": "PCI DSS", "hipaa": "HIPAA", "gdpr": "GDPR",
    "nist_800_53": "NIST 800-53", "tsc": "TSC", "gpg13": "GPG13",
}


def clean_text(value: Any, limit: int) -> str:
    """Strip control chars and bound length. Log text is attacker-influenced."""
    s = _CTRL.sub("", str(value)).strip()
    return s if len(s) <= limit else s[:limit] + " ...[truncated]"


def as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [str(v) for v in value]
    return [str(value)]


def flatten(d: dict, prefix: str = "", depth: int = 0, out: dict | None = None, max_keys: int = 25) -> dict:
    out = {} if out is None else out
    for k, v in d.items():
        if len(out) >= max_keys:
            break
        key = f"{prefix}{k}"
        if isinstance(v, dict) and depth < 2:
            flatten(v, key + ".", depth + 1, out, max_keys)
        elif isinstance(v, (str, int, float, bool)):
            out[key] = clean_text(v, 200)
        elif isinstance(v, list):
            out[key] = clean_text(", ".join(map(str, v[:10])), 200)
    return out


class AlertExtractor:
    def __init__(self, max_log_chars: int = 1500):
        self.max_log_chars = max_log_chars

    def extract(self, raw: dict | str | bytes) -> ExtractedAlert:
        if isinstance(raw, (str, bytes)):
            raw = json.loads(raw)
        if not isinstance(raw, dict):
            raise ValueError("Alert must be a JSON object")
        if isinstance(raw.get("_source"), dict):          # Wazuh indexer / OpenSearch hit wrapper
            raw = raw["_source"]
        rule = raw.get("rule")
        if not isinstance(rule, dict) and not raw.get("full_log"):
            raise ValueError("Not a Wazuh alert: no 'rule' object and no 'full_log'")
        rule = rule or {}
        mitre = rule.get("mitre") or {}
        agent = raw.get("agent") or {}

        try:
            level = int(rule.get("level"))
        except (TypeError, ValueError):
            level = None

        compliance = {label: as_list(rule.get(key)) for key, label in COMPLIANCE_KEYS.items() if rule.get(key)}
        data = raw.get("data")
        return ExtractedAlert(
            description=clean_text(rule.get("description") or "Unknown security event", 300),
            level=level,
            rule_id=str(rule["id"]) if rule.get("id") is not None else None,
            timestamp=raw.get("timestamp"),
            agent_name=agent.get("name"),
            agent_ip=agent.get("ip"),
            mitre_ids=as_list(mitre.get("id")),
            tactics=as_list(mitre.get("tactic")),
            techniques=as_list(mitre.get("technique")),
            compliance=compliance,
            log_detail=clean_text(raw.get("full_log") or "", self.max_log_chars),
            event_data=flatten(data) if isinstance(data, dict) else {},
            raw=raw,
        )


class LLMAlertSummarizer:
    """Paper-style Table 4 extraction with an LLM, with a hallucination guard."""

    def __init__(self, client: LLMClient, params: GenerationParams | None = None):
        self.client = client
        self.params = params or GenerationParams()

    def summarize(self, alert: ExtractedAlert) -> tuple[str, bool]:
        """Returns (summary_text, used_llm). Falls back to the deterministic text on any problem."""
        fallback = alert.to_text()
        prompt = EXTRACTION_PROMPT.format(input_event_json=json.dumps(alert.prompt_view(), indent=2, default=str))
        try:
            res = self.client.generate([{"role": "user", "content": prompt}], self.params)
        except Exception:
            return fallback, False
        text = res.text.strip()
        # Guard: every MITRE id Wazuh reported must survive, and no foreign technique ids may appear.
        found = set(re.findall(r"T\d{4}(?:\.\d{3})?", text))
        if any(i not in text for i in alert.mitre_ids) or (found - set(alert.mitre_ids) - {i.split('.')[0] for i in alert.mitre_ids}):
            return fallback, False
        return text, True
