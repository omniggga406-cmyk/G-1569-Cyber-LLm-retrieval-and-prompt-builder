"""Responsibilities 2 & 3: prompt templates, and combining alert + retrieved context.

Why a *builder* and not an f-string?
  - bounds the prompt (token budget) so context never crowds out the alert or the answer
  - filters irrelevant / duplicate chunks before the LLM sees them (garbage-in -> garbage-out)
  - tells the model how good its context is, so it can say "I'm unsure" instead of hallucinating
  - neutralises prompt-injection attempts that arrive through log text or poisoned documents
  - one place to version the prompt for the experiments in the report
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field

from .config import RetrievalPolicy
from .prompts import (EMPTY_CONTEXT, FOLLOWUP_PROMPT, PINNED_ALERT_PROMPT, QUALITY_NOTES,
                      REQUIRED_SECTIONS, RESPONSE_PROMPT, SYSTEM_PROMPT)
from .schemas import (QUALITY_GOOD, QUALITY_NONE, QUALITY_PARTIAL, ExtractedAlert,
                      RetrievedChunk, RetrievedContext)

_TAG = re.compile(r"</?\s*(alert|context|system|assistant|user)\b[^>]*>", re.I)


def neutralize(text: str) -> str:
    """Stop untrusted text from closing/opening our delimiter tags."""
    return _TAG.sub(lambda m: m.group(0).replace("<", "(").replace(">", ")"), text)


def est_tokens(text: str) -> int:
    return max(1, len(text) // 4)          # rough; swap for tiktoken if you want exact counts


@dataclass
class FilterReport:
    kept: dict[str, int] = field(default_factory=dict)
    dropped_low_score: dict[str, int] = field(default_factory=dict)
    dropped_duplicate: dict[str, int] = field(default_factory=dict)
    dropped_budget: dict[str, int] = field(default_factory=dict)
    exact_id_rescues: int = 0


@dataclass
class BuiltPrompt:
    messages: list[dict[str, str]]
    quality: str
    report: FilterReport
    context: RetrievedContext


class ContextFilter:
    def __init__(self, policy: RetrievalPolicy | None = None):
        self.policy = policy or RetrievalPolicy()

    def _is_exact_match(self, chunk: RetrievedChunk, alert: ExtractedAlert) -> bool:
        """A MITRE chunk whose technique id equals the alert's id is relevant regardless of score."""
        if chunk.source != "mitre" or not alert.mitre_ids:
            return False
        tid = str(chunk.metadata.get("technique_id", "")).upper()
        ids = {i.upper() for i in alert.mitre_ids}
        return bool(tid) and (tid in ids or tid.split(".")[0] in {i.split(".")[0] for i in ids})

    def apply(self, ctx: RetrievedContext, alert: ExtractedAlert) -> tuple[RetrievedContext, str, FilterReport]:
        rep, out = FilterReport(), RetrievedContext()
        for name, chunks in ctx.by_name().items():
            thr = self.policy.min_score.get(name, 0.55)
            seen: set[str] = set()
            ranked = sorted(chunks, key=lambda c: (c.score is None, -(c.score or 0.0)))
            kept: list[RetrievedChunk] = []
            budget = self.policy.max_tokens_per_collection
            for c in ranked:
                text = (c.text or "").strip()
                if not text:
                    continue
                exact = self._is_exact_match(c, alert)
                if not exact and c.score is not None and c.score < thr:
                    rep.dropped_low_score[name] = rep.dropped_low_score.get(name, 0) + 1
                    continue
                h = hashlib.sha1(re.sub(r"\s+", " ", text.lower()).encode()).hexdigest()
                if h in seen:
                    rep.dropped_duplicate[name] = rep.dropped_duplicate.get(name, 0) + 1
                    continue
                if len(kept) >= self.policy.max_chunks.get(name, 3):
                    rep.dropped_budget[name] = rep.dropped_budget.get(name, 0) + 1
                    continue
                cost = est_tokens(text)
                if cost > budget:
                    if kept:                        # keep at least one chunk, truncated, if nothing else fits
                        rep.dropped_budget[name] = rep.dropped_budget.get(name, 0) + 1
                        continue
                    text = text[: budget * 4] + " ...[truncated]"
                    cost = budget
                budget -= cost
                seen.add(h)
                rep.exact_id_rescues += int(exact and c.score is not None and c.score < thr)
                kept.append(RetrievedChunk(text, c.source, c.score, c.metadata))
            setattr(out, name, kept)
            rep.kept[name] = len(kept)
        return out, self.quality(out, alert), rep

    @staticmethod
    def quality(ctx: RetrievedContext, alert: ExtractedAlert) -> str:
        if ctx.total() == 0:
            return QUALITY_NONE
        need_mitre = alert.has_mitre
        if ctx.general and ctx.nist and (ctx.mitre or not need_mitre):
            return QUALITY_GOOD
        return QUALITY_PARTIAL


def render_chunks(chunks: list[RetrievedChunk]) -> str:
    if not chunks:
        return EMPTY_CONTEXT
    parts = []
    for i, c in enumerate(chunks, 1):
        score = f" (similarity {c.score:.2f})" if c.score is not None else ""
        parts.append(f"[{i}]{score} {neutralize(c.text)}")
    return "\n\n".join(parts)


class PromptBuilder:
    def __init__(self, policy: RetrievalPolicy | None = None):
        self.filter = ContextFilter(policy)

    def build_initial(self, alert: ExtractedAlert, ctx: RetrievedContext, alert_text: str | None = None) -> BuiltPrompt:
        fctx, quality, report = self.filter.apply(ctx, alert)
        user = RESPONSE_PROMPT.format(
            quality_note=QUALITY_NOTES[quality],
            context_general=render_chunks(fctx.general),
            context_nist=render_chunks(fctx.nist),
            context_mitre=render_chunks(fctx.mitre),
            alert_text=neutralize(alert_text or alert.to_text()),
            sections="\n".join(f"## {s}" for s in REQUIRED_SECTIONS),
        )
        msgs = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user}]
        return BuiltPrompt(msgs, quality, report, fctx)

    def pinned_messages(self, alert: ExtractedAlert, guide: str, alert_text: str | None = None) -> list[dict[str, str]]:
        """Compact conversation head reused for every follow-up (alert + the guide we already gave)."""
        return [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": PINNED_ALERT_PROMPT.format(alert_text=neutralize(alert_text or alert.to_text()))},
            {"role": "assistant", "content": guide},
        ]

    def build_followup(self, alert: ExtractedAlert, pinned: list[dict[str, str]], history: list[dict[str, str]],
                       question: str, extra_ctx: RetrievedContext | None) -> BuiltPrompt:
        ctx, quality, report = (RetrievedContext(), QUALITY_NONE, FilterReport())
        if extra_ctx is not None:
            ctx, quality, report = self.filter.apply(extra_ctx, alert)
        merged = [c for lst in (ctx.general, ctx.nist, ctx.mitre) for c in lst]
        user = FOLLOWUP_PROMPT.format(question=neutralize(question.strip()[:2000]), context=render_chunks(merged))
        return BuiltPrompt(pinned + history + [{"role": "user", "content": user}], quality, report, ctx)
