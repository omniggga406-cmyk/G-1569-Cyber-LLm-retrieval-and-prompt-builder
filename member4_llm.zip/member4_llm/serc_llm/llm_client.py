"""Responsibility 4: connect the LLM.

One interface, several backends. Everything the rest of the code knows about a model is
`LLMClient.generate(messages, params) -> LLMResult`, so swapping GPT-4o for Pixtral is one line.
Both OpenAI and Mistral expose OpenAI-compatible chat endpoints, so a single SDK covers both.
"""
from __future__ import annotations

import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass

from .config import MODELS, GenerationParams, ModelSpec

Messages = list[dict[str, str]]


@dataclass
class LLMResult:
    text: str
    model: str
    latency_s: float
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    finish_reason: str | None = None


class LLMClient(ABC):
    name: str = "llm"

    @abstractmethod
    def generate(self, messages: Messages, params: GenerationParams) -> LLMResult: ...


class OpenAICompatibleClient(LLMClient):
    def __init__(self, spec: ModelSpec, timeout: float = 120.0, retries: int = 3):
        from openai import OpenAI  # lazy import so tests run without the SDK

        key = os.environ.get(spec.api_key_env)
        if not key:
            raise RuntimeError(f"Set the {spec.api_key_env} environment variable")
        self.spec, self.retries, self.name = spec, retries, spec.label
        self._client = OpenAI(api_key=key, base_url=spec.base_url, timeout=timeout)

    def generate(self, messages: Messages, params: GenerationParams) -> LLMResult:
        kwargs = dict(model=self.spec.model, messages=messages,
                      temperature=params.temperature, top_p=params.top_p,
                      **{self.spec.token_param: params.max_tokens})
        if self.spec.supports_top_k:
            kwargs["extra_body"] = {"top_k": params.top_k}   # vLLM / self-hosted only
        last_err: Exception | None = None
        for attempt in range(self.retries):
            t0 = time.perf_counter()
            try:
                r = self._client.chat.completions.create(**kwargs)
                ch = r.choices[0]
                return LLMResult(
                    text=ch.message.content or "", model=self.spec.model,
                    latency_s=time.perf_counter() - t0,
                    prompt_tokens=getattr(r.usage, "prompt_tokens", None),
                    completion_tokens=getattr(r.usage, "completion_tokens", None),
                    finish_reason=ch.finish_reason)
            except Exception as e:  # rate limit, timeout, 5xx ...
                last_err = e
                time.sleep(2 ** attempt)
        raise RuntimeError(f"LLM call failed after {self.retries} attempts: {last_err}")


def make_client(key: str) -> LLMClient:
    return OpenAICompatibleClient(MODELS[key])


class FakeLLMClient(LLMClient):
    """Deterministic stand-in for unit tests and offline demos."""

    def __init__(self, name: str = "fake", responder=None):
        self.name = name
        self.calls: list[Messages] = []
        self._responder = responder

    def generate(self, messages: Messages, params: GenerationParams) -> LLMResult:
        self.calls.append(messages)
        text = self._responder(messages) if self._responder else default_fake_answer(messages)
        return LLMResult(text=text, model=self.name, latency_s=0.0, prompt_tokens=0, completion_tokens=0, finish_reason="stop")


def default_fake_answer(messages: Messages) -> str:
    from .prompts import REQUIRED_SECTIONS
    return "\n\n".join(f"## {s}\n(placeholder)" for s in REQUIRED_SECTIONS)
