"""Responsibility 7: compare model responses.

Mirrors the paper (cosine similarity with bge-large-en-v1.5 + BERTScore P/R/F1 vs a ground-truth
playbook) and adds latency/cost and structural checks that the paper does not report.

CAVEAT worth stating in the report/viva: bge-large and BERTScore models truncate at 512 tokens, so a
long answer is only scored on its head. We chunk and average to avoid that.
"""
from __future__ import annotations

import re
from statistics import mean, pstdev

from .response_generator import missing_sections, unverified_technique_ids


def _chunks(text: str, words: int = 300) -> list[str]:
    w = text.split()
    return [" ".join(w[i:i + words]) for i in range(0, max(len(w), 1), words)] or [""]


def cosine_scores(cands: list[str], refs: list[str], model_name: str = "BAAI/bge-large-en-v1.5") -> list[float]:
    import numpy as np
    from sentence_transformers import SentenceTransformer
    m = SentenceTransformer(model_name)

    def emb(t: str):
        v = m.encode(_chunks(t), normalize_embeddings=True).mean(axis=0)
        return v / (np.linalg.norm(v) + 1e-12)

    return [float(emb(c) @ emb(r)) for c, r in zip(cands, refs)]


def bertscore(cands: list[str], refs: list[str]) -> dict[str, list[float]]:
    from bert_score import score
    P, R, F = score(cands, refs, lang="en", verbose=False)     # default roberta-large, no baseline rescale
    return {"precision": P.tolist(), "recall": R.tolist(), "f1": F.tolist()}


def structural(text: str, alert, ctx) -> dict[str, float]:
    return {
        "missing_sections": len(missing_sections(text)),
        "unverified_ids": len(unverified_technique_ids(text, alert, ctx)),
        "mentions_alert_technique": float(all(i in text for i in alert.mitre_ids)) if alert.mitre_ids else 1.0,
        "words": len(text.split()),
    }


def summarize(rows: list[dict], key: str) -> dict[str, tuple[float, float]]:
    """mean / std of metric `key` per model label."""
    out: dict[str, list[float]] = {}
    for r in rows:
        if r.get(key) is not None:
            out.setdefault(r["model"], []).append(float(r[key]))
    return {m: (mean(v), pstdev(v) if len(v) > 1 else 0.0) for m, v in out.items()}


def wilcoxon(rows: list[dict], key: str, a: str, b: str) -> float | None:
    """Paired Wilcoxon p-value across scenarios (needs scipy and >= 6 paired samples)."""
    try:
        from scipy.stats import wilcoxon as w
    except ImportError:
        return None
    by = {(r["scenario"], r["model"]): r[key] for r in rows if r.get(key) is not None}
    sc = sorted({s for s, m in by if m == a} & {s for s, m in by if m == b})
    if len(sc) < 6:
        return None
    return float(w([by[(s, a)] for s in sc], [by[(s, b)] for s in sc]).pvalue)
