"""The contract between Member 3 (retrieval) and Member 4 (generation).

Member 3 implements `retrieve`. Until then use StubRetriever so you can develop and test alone.
"""
from __future__ import annotations

from typing import Protocol

from .schemas import ExtractedAlert, RetrievedChunk, RetrievedContext


class Retriever(Protocol):
    def retrieve(self, alert: ExtractedAlert, query: str | None = None) -> RetrievedContext:
        """`query` is set for follow-up questions; None for the initial alert."""
        ...


class StubRetriever:
    """Canned context for offline development. Replace with Member 3's Qdrant retriever."""

    def __init__(self, ctx: RetrievedContext | None = None):
        self.ctx = ctx or sample_context()

    def retrieve(self, alert: ExtractedAlert, query: str | None = None) -> RetrievedContext:
        return self.ctx


def sample_context() -> RetrievedContext:
    return RetrievedContext(
        general=[RetrievedChunk(
            "Containment: isolate affected endpoints, preserve volatile evidence (memory, logs) before remediation, "
            "and notify the incident commander. Eradication: remove persistence and reset affected credentials. "
            "Recovery: restore from known-good backups and monitor for recurrence.",
            "general", 0.78, {"doc": "incident-response-guide"})],
        nist=[RetrievedChunk(
            "DE.CM (Continuous Monitoring): assets are monitored to find anomalies and indicators of compromise. "
            "RS.MA (Incident Management): responses to detected incidents are managed. "
            "RC.RP (Incident Recovery Plan Execution): restoration activities are performed.",
            "nist", 0.74, {"doc": "csf-2.0"})],
        mitre=[RetrievedChunk(
            "T1562.001 Impair Defenses: Disable or Modify Tools. Adversaries may disable security tools to avoid detection. "
            "Mitigations: M1022 Restrict File and Directory Permissions, M1038 Execution Prevention, M1018 User Account Management. "
            "Detection: monitor for changes to agent services and processes.",
            "mitre", 0.83, {"technique_id": "T1562.001"})],
    )
