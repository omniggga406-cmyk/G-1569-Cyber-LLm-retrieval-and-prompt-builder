"""Offline end-to-end demo (no API key needed):  python demo.py
Set USE_REAL=gpt4o (or pixtral) with the matching API key to call a real model."""
import json
import os

from serc_llm.conversation import FollowUpSession
from serc_llm.llm_client import FakeLLMClient, make_client
from serc_llm.response_generator import SERCResponder
from serc_llm.retriever_iface import StubRetriever

raw = json.load(open("data/sample_alert.json"))
real = os.environ.get("USE_REAL")
client = make_client(real) if real else FakeLLMClient()
responder = SERCResponder(client, StubRetriever())

result = responder.analyze(raw)
print("=== EXTRACTED ALERT ===\n" + result.alert_text)
print("\n=== PROMPT SENT TO LLM (user message) ===\n" + result.prompt.messages[1]["content"])
print("\n=== RESPONSE ===\n" + result.response)
print("\nquality:", result.quality, "| warnings:", result.warnings)

chat = FollowUpSession(responder, result)
answer, meta, q = chat.ask("How do I check whether the agent was stopped by an attacker?")
print("\n=== FOLLOW-UP ===\n" + answer)
